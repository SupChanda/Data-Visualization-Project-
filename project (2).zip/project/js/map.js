class Map{



  constructor(data){
	  
  
	
     let map = d3.select("#mapChart").classed("map", true);
	 //let showOptions = d3.select("#chooseOptions").classed("chooseOptions", true);
	 this.projection = d3.geoConicConformal().scale(150).translate([400, 350]);
     this.hdi=data;
	 
  };
	//showOptions(data)
  showmap(world){
	//console.log('this.hdi',this.hdi)
		  
		  let data= this.hdi;
     this.path = d3.geoPath()
            .projection(this.projection);
    this.graticule = d3.geoGraticule();
 
  let nworld = topojson.feature(world, world.objects.countries);
  
  let tooltip = new Tooltip()
  let map = d3.select("#map").append('svg').attr('width',900).attr('height',600).attr("transform", "translate(" + 50 + ",0)").append('g');
        //draw the initial map
        let mapPath = map.selectAll("path")
            .data(nworld.features)
            .enter()
            .append("path")
            .attr("class", "countries")
            .attr("id", function (d,i) {
			    //console.log(d.id);
                return d.id;
            })
            
            .attr("d", this.path)
			
			.on('click',function (d) {
				
				let dChart = new donutChart()
				dChart.categoryName(d.id)
				//console.log('yearrrrrrrrrr',d)
				let color = d3.scaleLinear()
							  .domain([0,1])
							  .range([0,255]);
				let year=parseInt(d3.select('#yearname').select('.yearselecter').attr('cx'));
				
				year=(year-30)/30 + 1990
			    console.log(year);
				
				for (let j=0;j<data.length;j++){
					 
					//console.log(j,data[j]);
					d3.select('#'+data[j].Country_Code)
						.attr('fill',"rgb(" +"0, " + color(parseFloat(data[j][year.toString()]))   + ",0 )");
					
					
				}
				
				d3.select(this).attr('fill','orange')
				let infopanel = new Infopanel();
			    infopanel.viewinfo(data,d.id);
			})
			.on('mouseover',function(d){
				//console.log('on mousover',d.id,'this.hdi',data)
				let c_code = d
				let tempYr=[]
				for(var i=0;i<data.length;i++){
					//console.log('first dataa',data[i],data[i]['Country_Code'],data[i]['2017'])
					tempYr.push({'Country_Code': data[i]['Country_Code'],'2017':data[i]['2017'],'Country':data[i]['Country']})
				}
				//console.log('tempYr',tempYr)
				tempYr.forEach(function(d){
					//console.log('yyy',d)
					//console.log('c_code',c_code)
					if (c_code.id == d.Country_Code){
						//console.log('c_code',c_code.id)
						tooltip.mouseover(d)
						tooltip.mousemove(d)
					}
					
				})
			})
			.on('mouseout',function(d){
				tooltip.mouseout(d)
			})
			;
   	
	 let graticulePath = map.append("path")
            .datum(this.graticule)
            .attr("class", "grat")
            .attr("d", this.path)
            .attr("fill", "none");
	
	this.changecolor(27);
  
  
    //console.log('data',data)
    let yearchar= d3.select("#year").append('svg').attr('width',930).attr('height',100).attr("transform", "translate(" + 50 + ",0)");
	let year=[1990,1991,1992,1993,1994,1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,2005,2006,2007,2008,2009,2010,2011,2012,2013,2014,2015,2016,2017];
	yearchar = yearchar.append('g').attr('id','yearname').selectAll('circle').data(year)
	                   .enter()
					   .append('circle')
					   .attr('id',function(d,i){
						   //console.log('yearffffff',d,typeof(d))
						   
						   return 'year'+ d.toString()
					    })
					   .attr('cx',(d,i)=>i*30+30)
					   .attr('cy',40)
					   .attr('r',6)
					   .attr('fill','red')
					   .attr('class','none')
					   .on('click',function(d,i){
						   d3.select("#infopanel").select('svg').remove()
						   //console.log('year is coming fine: ',yrSel)
						   d3.selectAll('circle').attr('class','none').attr('fill','red');
						   //console.log('d3 select',d3.select(this),d,typeof(d))
							d3.select("#year"+ d).attr('class','yearselecter')
							let color = d3.scaleLinear()
							  .domain([0,1])
							  .range([0,255]);
							let year=1990+i;
							
							for (let j=0;j<data.length;j++){
								 
								//console.log(j,data[j].Country_Code,color(parseFloat(data[j][year.toString()])));
								d3.select('#'+data[j].Country_Code)
								
								.attr('fill',"rgb(" +"0, " + color(parseFloat(data[j][year.toString()]))   + ",0 )");
							}
	
						   
						   
					   })
					   ;
	d3.select('#year2017').attr('class','yearselecter')
	let selectedyear=[1990,1993,1996,1999,2002,2005,2008,2011,2014,2017]
	let yeartext = d3.select("#year").select('svg').append('g').selectAll('text').data(selectedyear)
	                   .enter()
					   .append('text')
					   .attr('x',(d,i)=>i*90+15)
					   .attr('y',70)
					   .attr('r',4)
					   
					   .text((d,i)=>selectedyear[i])
					   ;
	
	let button = d3.select("#year").select('svg').append('g').selectAll('rect').data([1567])
	                   .enter()
					   .append('rect')
					   .attr('id',"button")
					   .attr('x',870)
					   .attr('y',30)
					   .attr('height',20)
					   .attr('width',100)
					   
					   .attr('fill','yellow')
					   .on('click', d=>this.video())
		;
	
	let buttontext = d3.select("#year").select('svg').selectAll('line').append('g').data([1567])
	                   .enter()
					   .append('text')
					   .attr('x',880)
					   .attr('y',45)
					   
					   
					   .text("Next")
					   ;
  };
  
  changecolor(i){
	  //console.log('iiiii',i)
  d3.select('#yearname').selectAll('circle').attr('class','None');
    let color = d3.scaleLinear()
      .domain([0,1])
      .range([0,255]);
    let year=1990+i;
	
    for (let j=0;j<this.hdi.length;j++){
		 
	    //console.log(j,this.hdi[j].Country_Code,color(parseFloat(this.hdi[j][year.toString()])));
	    d3.select('#'+this.hdi[j].Country_Code)
		.transition()
		.delay(100)
		.duration(100)
		.attr('fill',"rgb(" +"0, " + color(parseFloat(this.hdi[j][year.toString()]))   + ",0 )");
	
	
	}
  
  
  
  };
  
   video(){
    let year=parseInt(d3.select('#yearname').select('.yearselecter').attr('cx'));
	d3.select('#yearname').selectAll('circle').attr('class','none').attr('fill','red');
	let color = d3.scaleLinear()
							  .domain([0,1])
							  .range([0,255]);
	year=(year-30)/30 + 1990 +1;
	console.log(year);    
    if (year==2018)
		year=1990
	for (let j=0;j<this.hdi.length;j++){
					 
					//console.log(j,data[j]);
					d3.select('#'+this.hdi[j].Country_Code)
						.attr('fill',"rgb(" +"0, " + color(parseFloat(this.hdi[j][year.toString()]))   + ",0 )");
					
					
				}	
		
	
    d3.select('#year'+year).attr('class','yearselecter')
  };
  
  


}