
let optList = ['HDI','Population']
	d3.select("#chooseOptions")
	//.attr('class','chooseOptions')
			.selectAll("option")
             .data(optList)
             .enter()
             .append("option")
             .attr("value", function(d){
				 return d;
			 })
             .text(function(d){
				 return d;
			 })
			 .call(csvFetch('HDI'))
			 ;
	 let selectedValue = ''
	d3.select("#chooseOptions").on('change',function(d){
				 console.log('options are coming',d3.select(this).property("value"))
				 selectedValue = d3.select(this).property("value");
			 
			 })
			 
			 
      ;
			
csvFetch(optValue){
	let selValue= '';
		if (optValue == 'HDI'){
			setValue = 'country_code_with_Info_Panel.csv'
		}else{
			setValue = 'Population_in_millions.csv'
		}
		d3.csv("data/"+ setValue,function(d){
				return d;
			 
			 }).then(function(alldata){


		let mapview=new Map(alldata);

		// let dChart = new donutChart()
		// dChart.categoryName()
		d3.json("data/world.json")
			.then(function(world) {
			  mapview.showmap(world);
			});
		});
}

