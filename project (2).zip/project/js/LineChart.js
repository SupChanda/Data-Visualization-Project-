class LineChart{
	constructor(){
		
		let lineChart = d3.select("#lineChart").classed("lineChart", true);
		
	};
	drawLineChart(alldata,country){
		//let year=[1990,1991,1992,1993,1994,1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,2005,2006,2007,2008,2009,2010,2011,2012,2013,2014,2015,2016,2017];
		
		let j=0
		for (j=0;j<alldata.length;j++){
		 
		 if (alldata[j]['Country_Code']==country){
			 break
		 }
		 
	 }
     let data=[];
	 data.push(alldata[j]);
	 
	 let yearName= []
	 
	 //console.log(data);	
	 let yearList=[]
	 d3.keys(data[0]).forEach(function(d){
		 //console.log('dddddatatttt',typeof(d),d)
		 if(d.includes('Country')== false){
			 yearName.push(d)
		}
	 })
	 let yearValue=[]
	 console.log('yearName',yearName)
	 d3.values(data[0]).forEach(function(d){
		 if(/[^a-zA-Z]+$/.test(d)==true){
			 yearValue.push(d)
		 }
	 })
	 for(var i=0;i<yearName.length;i++){
		 let Name={}
		 Name[yearName[i]]=yearValue[i]
		 yearList.push(Name)
	 }
	 console.log('yearLIST',yearList)
	 console.log('yearValue',yearValue,d3.max(yearValue))
	 let yscale = d3.scaleLinear().domain([0,parseFloat(d3.max(yearValue))]).range([400,0])
	 let xscale = d3.scaleLinear().domain([d3.min(yearName),d3.max(yearName)]).range([0,680])
	 var x_axis = d3.axisBottom()
                   .scale(xscale);
     var y_axis = d3.axisLeft()
                   .scale(yscale);
	let lChart = d3.select('#LineChart')
					.append('svg')
					.attr('width',750)
					.attr('height',500)
					
	lChart.append('g').attr('transform','translate(30,450)').call(x_axis)
	lChart.append('g').attr('transform','translate(22,50)').call(y_axis)
	var line = d3.line()
				.x(function(d,i) { 
						console.log('yearName1',yearName[i])
						return xscale(parseInt(yearName[i])); 
				}) // set the x values for the line generator
				.y(function(d,i) { 
						console.log('yearValue1',yearValue[i])
						return yscale(parseFloat(yearValue[i])); }) // set the y values for the line generator 
				.curve(d3.curveMonotoneX) // apply smoothing to the line
	lChart
	.append('g')
	.attr('transform','translate(31,49)')
	.append("path")
    .datum(yearList)
    .attr("fill","none")	
	.attr("stroke","steelblue")
	.attr("stroke-width",2)
    .attr("d", line); // 11. Calls the line generator 
					
	};

}