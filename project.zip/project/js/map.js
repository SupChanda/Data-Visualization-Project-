class Map{



  constructor(infopanel,data){
  
  this.infopanel=infopanel;
     let map = d3.select("#mapChart").classed("map", true);
	 this.projection = d3.geoConicConformal().scale(150).translate([400, 350]);
     this.hdi=data;
   
  };

  showmap(world){
  console.log('this.hdi',this.hdi)
  let infopanel=this.infopanel;
  let data= this.hdi;
     this.path = d3.geoPath()
            .projection(this.projection);
    this.graticule = d3.geoGraticule();
 
  let nworld = topojson.feature(world, world.objects.countries);
  
  
  let map = d3.select("#map").append('svg').attr('width',900).attr('height',600).attr("transform", "translate(" + 50 + ",0)").append('g');
        //draw the initial map
        let mapPath = map.selectAll("path")
            .data(nworld.features)
            .enter()
            .append("path")
            .attr("class", "countries")
            .attr("id", function (d, i) {
			    console.log(d.id);
                return d.id;
            })
            
            .attr("d", this.path)
			
			.on('click',function (d) {
				// let color = d3.scaleLinear()
							  // .domain([0,1])
							  // .range([0,255]);
				// let year=1990+i;
				
				// for (let j=0;j<data.length;j++){
					 
					// console.log(j,data[j].Country_Code,color(parseFloat(data[j][year.toString()])));
					// d3.select('#'+data[j].Country_Code)
					
					// .attr('fill',"rgb(" +"0, " + color(parseFloat(data[j][year.toString()]))   + ",0 )");
				// }
				
				d3.select(this).attr('fill','orange')
				
			    infopanel.viewinfo(0);
			})
			;
   	
	 let graticulePath = map.append("path")
            .datum(this.graticule)
            .attr("class", "grat")
            .attr("d", this.path)
            .attr("fill", "none");
	
	this.changecolor(27);
  
	
    //console.log('data',data)
    let yearchar= d3.select("#year").append('svg').attr('width',930).attr('height',100).attr("transform", "translate(" + 50 + ",0)");
	let year=[1990,1991,1992,1993,1994,1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,2005,2006,2007,2008,2009,2010,2011,2012,2013,2014,2015,2016,2017];
	yearchar = yearchar.append('g').attr('id','yearname').selectAll('circle').data(year)
	                   .enter()
					   .append('circle')
					   .attr('id',function(d,i){
						   //console.log('yearffffff',d,typeof(d))
						   
						   return 'year'+ d.toString()
					    })
					   .attr('cx',(d,i)=>i*30+30)
					   .attr('cy',40)
					   .attr('r',6)
					   .attr('fill','red')
					   .on('click',function(d,i){
						   d3.selectAll('circle').attr('fill','red')
						   console.log('d3 select',d3.select(this),d,typeof(d))
							d3.select("#year"+ d).attr('fill','green')
							let color = d3.scaleLinear()
							  .domain([0,1])
							  .range([0,255]);
							let year=1990+i;
							
							for (let j=0;j<data.length;j++){
								 
								console.log(j,data[j].Country_Code,color(parseFloat(data[j][year.toString()])));
								d3.select('#'+data[j].Country_Code)
								
								.attr('fill',"rgb(" +"0, " + color(parseFloat(data[j][year.toString()]))   + ",0 )");
							}
	
						   
						   
					   })
					   ;
	   d3.select('#year2017').attr('fill','green')
	let selectedyear=[1990,1993,1996,1999,2002,2005,2008,2011,2014,2017]
	let yeartext = d3.select("#year").select('svg').append('g').selectAll('text').data(selectedyear)
	                   .enter()
					   .append('text')
					   .attr('x',(d,i)=>i*90+15)
					   .attr('y',70)
					   .attr('r',4)
					   
					   .text((d,i)=>selectedyear[i])
					   ;
	
	let button = d3.select("#year").select('svg').append('g').selectAll('rect').data([1567])
	                   .enter()
					   .append('rect')
					   .attr('id',"button")
					   .attr('x',870)
					   .attr('y',30)
					   .attr('height',20)
					   .attr('width',100)
					   
					   .attr('fill','yellow')
					   .on('click', function(d,i){
					     let x = document.getElementsByClassName("selected")
						 console.log(x);
					   })
		;
	
	let buttontext = d3.select("#year").select('svg').selectAll('line').append('g').data([1567])
	                   .enter()
					   .append('text')
					   .attr('x',880)
					   .attr('y',45)
					   
					   
					   .text("Next")
					   ;
  };
  
  changecolor(i){
	  console.log('iiiii',i)
  d3.select('#yearname').selectAll('circle').attr('class','None');
    let color = d3.scaleLinear()
      .domain([0,1])
      .range([0,255]);
    let year=1990+i;
	
    for (let j=0;j<this.hdi.length;j++){
		 
	    //console.log(j,this.hdi[j].Country_Code,color(parseFloat(this.hdi[j][year.toString()])));
	    d3.select('#'+this.hdi[j].Country_Code)
		.transition()
		.delay(100)
		.duration(100)
		.attr('fill',"rgb(" +"0, " + color(parseFloat(this.hdi[j][year.toString()]))   + ",0 )");
	
	
	}
  
  
  
  };
  
   video(i){
        function delay(time){
		  let d1=new Date();
		  let d2=new Date();
		  while(d2.valueOf()<d1.valueOf()+time){
		    d2=new Date();
		  }
		
		
		}
		console.log(i);
		if (i<5)
		d3.call(this.changecolor(1)).then( video(i+1));
  
		
		
	
  
  };
  
  


}