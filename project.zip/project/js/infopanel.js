class Infopanel{



  constructor(){
     let infopanel = d3.select("#infopanel").classed("infopanel", true);
     this.margin = {top: 15, right: 10, bottom: 15, left: 25};
    //Gets access to the div element created for this chart and legend element from HTML
    this.svg = infopanel.append("svg")
	                    .attr("height",700)
						.attr("weight",400)
						.attr("transform", "translate(" + 20 + ",0)")
						;
  
  
  
  
  
  
  };

  viewinfo(i){
     let data=['Bangladesh','a.png'];
	 let name = this.svg.append('g').selectAll("text").data(data);
	 name=name.enter().append('text').merge(name)
	                           .attr('x', 50)
							   .attr('y', 50)
							   .text("Name : ")
							   
							   ;
							   
	 let countryname = this.svg.append('g').selectAll("text").data(data);
	 countryname=countryname.enter().append('text')
							   .merge(countryname)
							   .attr('x', 130)
							   .attr('y', 50)
							   .text("Bangladesh")
							   ;
	
	
	let fname = this.svg.append('g').selectAll("text").data(data);
	 fname=fname.enter().append('text').merge(fname)
	                           .attr('x', 50)
							   .attr('y', 100)
							   .text("Flag : ")
							   
							   ;
	
     let flag = this.svg.append('g').selectAll("image").data(data);
	 flag = flag.enter().append("image")
	                    .attr('x', 100)
						.attr('y', 60)
						.attr("xlink:href", "bd.png")
						.attr("width", 150)
                        .attr("height", 100)
						;
						
	let pname = this.svg.append('g').selectAll("text").data(data);
	 pname=pname.enter().append('text').merge(pname)
	                           .attr('x', 50)
							   .attr('y', 170)
							   .text("Population : ")
	let population = this.svg.append('g').selectAll("text").data(data);
	 population=population.enter().append('text').merge(population)
	                           .attr('x', 130)
							   .attr('y', 170)
							   .text(120000)
							   ;	
    
    let cname = this.svg.append('g').selectAll("text").data(data);
	 cname=cname.enter().append('text').merge(cname)
	                           .attr('x', 50)
							   .attr('y', 190)
							   .text("Capital : ")
	let capital = this.svg.append('g').selectAll("text").data(data);
	 capital=capital.enter().append('text').merge(capital)
	                           .attr('x', 130)
							   .attr('y', 190)
							   .text("Dhaka")
							   ;	
    
	let cuname = this.svg.append('g').selectAll("text").data(data);
	 cuname=cuname.enter().append('text').merge(cuname)
	                           .attr('x', 50)
							   .attr('y', 210)
							   .text("Currency : ")
	let currency = this.svg.append('g').selectAll("text").data(data);
	 currency=currency.enter().append('text').merge(currency)
	                           .attr('x', 130)
							   .attr('y', 210)
							   .text("Taka")
							   ;
							   
	let chid = this.svg.append('g').selectAll("text").data(data);
	 chid=chid.enter().append('text').merge(chid)
	                           .attr('x', 50)
							   .attr('y', 230)
							   .text("HID (Rank) : ")
	let hid = this.svg.append('g').selectAll("text").data(data);
	 hid=hid.enter().append('text').merge(hid)
	                           .attr('x', 140)
							   .attr('y', 230)
							   .text("120")
							   ;
    let narea = this.svg.append('g').selectAll("text").data(data);
	 narea=narea.enter().append('text').merge(narea)
	                           .attr('x', 50)
							   .attr('y', 250)
							   .text("Area : ")
	let area = this.svg.append('g').selectAll("text").data(data);
	 area=area.enter().append('text').merge(area)
	                           .attr('x', 140)
							   .attr('y', 250)
							   .text("120 mi^2")
							   ;
  };


}