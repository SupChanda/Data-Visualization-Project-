d3.csv("data/country_code.csv",function(d){
	    return d;
	 
	 }).then(function(alldata){
let infopanel = new Infopanel();

let mapview=new Map(infopanel,alldata);


d3.json("data/world.json")
    .then(function(world) {
      mapview.showmap(world);
    });
});